package com.example.demo;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TwilioInitializer {

	 public static final String ACCOUNT_SID = "ACd635bd3d53229b3294493c9e9e3f9197";
	  public static final String AUTH_TOKEN = "57475544f5cf239298988b387edb45ae";

	  public static void main(String[] args) {
	    Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

	    Message message = Message.creator(new PhoneNumber("+917697536141"),
	        new PhoneNumber("+18635937535"), 
	        "your Oppointment has been Scheduled dated 25-Apr-2019").create();

	    System.out.println(message.getSid());
	  }
	}