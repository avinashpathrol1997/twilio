# springboot-twilio
- Open and change application.yml
```yml
twilio:
  account_sid: #your account sid
  auth_token: #your auth token
  trial_number: # your trial number
```
- Run the application
- Start sending sms's
- That simple
